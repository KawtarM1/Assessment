
"""
Created on Thu Aug 17 15:17:07 2023

@author: mouba
"""

from behave import given, when, then
from enum import Enum

class UserRole(Enum):
    Admin="Admin"
    User="User"

# Frontend scenario steps
@given('I am logged as admin (frontend)')
def step_given_admin_frontend(context):
    context.user_role = UserRole.ADMIN

        
@when('I am in Users page')
def step_when(context):
    context.browser = Browser("https://myweb.com")
    context.user_list = get_user_list_from_website(context.browser)

@then('4 users are listed')
def step_then(context):
    assert len(context.user_list) == 4

# Frontend scenario steps
@then('1 of them is Administrator (frontend)')
def step_then_administrator_frontend(context):
    admin_user_found = any(user['role'] == 'Administrator' for user in context.user_list)
    assert admin_user_found, "Administrator user not found in website user list."

# API scenario steps
@given('I am logged as admin (API)')
def step_given_admin_api(context):
    context.user_role = UserRole.ADMIN

@when('I request API GET api/v1/users')
def step_when(context):
    context.api = API("https://api.myweb.com")
    context.api_response = context.api.request("GET", "api/v1/users")

@then('I get HTTP 200 status code')
def step_then(context):
    assert context.api_response.status_code == 200

@then('I get JSON in response body')
def step_then(context):
    try:
        json_response = context.api_response.json()
    except ValueError:
        assert False, "API response is not in JSON format."

@then('the HTTP response body contains a page with 4 users')
def step_then(context):
    json_response = context.api_response.json()
    assert len(json_response['data']) == 4

@then('1 of them is Administrator (API)')
def step_then_administrator_api(context):
    json_response = context.api_response.json()
    admin_user_found = any(user['role'] == 'Administrator' for user in json_response['data'])
    assert admin_user_found, "Administrator user not found in API response."

