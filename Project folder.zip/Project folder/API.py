
"""
Created on Thu Aug 17 17:10:23 2023

@author: mouba
"""

import requests
from typing import List,Dict

class API:
    def __init__(self, url: str):
        self.url = url
    
    def request(self, http_method: str, endpoint: str):
        full_url = f"{self.url}/{endpoint}"
        
        if http_method == 'GET':
            response = requests.get(full_url)
        elif http_method == 'POST':
            response = requests.post(full_url)
        
        return response.json()  # Return the response content as JSON
