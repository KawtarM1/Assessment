
"""
Created on Thu Aug 17 17:11:24 2023

@author: mouba
"""

from bs4 import BeautifulSoup
import requests
from typing import List,Dict

class Browser:
    def __init__(self, url: str):
        self.url = url
    
    def find_object(self, object_name: str):
        response = requests.get(self.url)
        soup = BeautifulSoup(response.content, 'html.parser')
        found_object = soup.find(object_name)
        return found_object

def get_user_list_from_website(browser: Browser) -> List[Dict[str, str]]:
    user_list = []
    table_element = browser.find_object("user_list_table")
    rows = table_element.find_all("tr")
    
    for row in rows[1:]:
        columns = row.find_all("td")
        user = {
            "Last_name": columns[0].text,
            "First_name": columns[1].text,
            "email_address": columns[2].text,
            "confirmed": columns[3].text == "Confirmed",
            "actions": columns[8].find("a")["href"]
        }
        user_list.append(user)
    
    return user_list